#include "zero_check.h" //读取头文件
void zero_check_ecd(int32_t *target, int32_t now) //一个指的是目标值，一个指的是当前值
{
    int32_t diff = now - *target;//差值
    if (diff > ZERO_ECD_HALF)//如果差值大于半圈
        *target += ZERO_ECD_CIRCLE;//加上整圈
    else if (diff < -ZERO_ECD_HALF)//如果差值小于负半圈
        *target -= ZERO_ECD_CIRCLE;//减去整圈
}

void zero_check_angle(float *target, float now)  //函数2与半圈比较
{
    float diff = now - *target;//差值，角度可能带小数，用浮点型
    if (diff > ZERO_ANGLE_HALF)//如果差值大于半圈
        *target += ZERO_ANGLE_CIRCLE;//加上整圈
    else if (diff < -ZERO_ANGLE_HALF)//如果差值小于负半圈
        *target -= ZERO_ANGLE_CIRCLE;//减去整圈
}