#include "curve_ctrl.h" //读取头文件
void curve_reset(curve_ctrl_t *ctrl)
    {
        if (ctrl == NULL)
            return;
        ctrl->out = 0.0f; //输出清零
        ctrl->first_run = 1; //第一次运行标志置1
    }
curve_status_t curve_init(curve_ctrl_t *ctrl, const curve_config_t *cfg)
    {
        if (ctrl == NULL || cfg == NULL) //如果指针为空
            return CURVE_ERR_NULL; //返回空指针错误
        if (cfg->e_range <= 0.0f || cfg->out_max <= 0.0f || cfg->slew_max <= 0.0f) //如果量程、折点输出、变化率或限幅不合法
            return CURVE_ERR_PARAM; //返回参数错误
        for (uint8_t i = 1; i < CURVE_POINT_COUNT; i++) //检查折点输出是否单调不减
        {
            if (cfg->out_pt[i] < cfg->out_pt[i - 1]) //如果折点输出不满足单调不减
                return CURVE_ERR_PARAM; //返回参数错误
        }
        ctrl->cfg = *cfg; //将配置参数存入结构体
        ctrl->out = 0.0f; //输出清零
        ctrl->first_run = 1; //第一次运行标志置1
        return CURVE_OK; //返回成功
    }
float curve_update(curve_ctrl_t *ctrl, float setpoint, float measured, float dt)
    {
        if (ctrl == NULL) //如果指针为空
            return 0.0f; //返回0.0f
        if (dt <= 0.0f) //如果时间间隔小于等于0
            return 0.0f; //返回0.0f
        float error = setpoint - measured; //计算误差
        if (error < -ctrl->cfg.e_range) //如果误差小于负量程
            error = -ctrl->cfg.e_range; //将误差限制为负量程
        else if (error > ctrl->cfg.e_range) //如果误差大于量程
            error = ctrl->cfg.e_range; //将误差限制为量程
        float out_target = 0.0f; //目标输出初始化为0.0f
        for (uint8_t i = 1; i < CURVE_POINT_COUNT; i++) //遍历折点输出
        {
            float e_prev = -ctrl->cfg.e_range + (2.0f * ctrl->cfg.e_range / (CURVE_POINT_COUNT - 1)) * (i - 1); //前一个折点的误差值
            float e_next = -ctrl->cfg.e_range + (2.0f * ctrl->cfg.e_range / (CURVE_POINT_COUNT - 1)) * i; //下一个折点的误差值
            if (error >= e_prev && error <= e_next) //如果误差在两个折点之间
            {
                float t = (error - e_prev) / (e_next - e_prev); //计算插值系数
                out_target = ctrl->cfg.out_pt[i - 1] + t * (ctrl->cfg.out_pt[i] - ctrl->cfg.out_pt[i - 1]); //线性插值计算目标输出
                break; //跳出循环
            }
        }
        if (ctrl->first_run) //如果是第一次运行
        {
            ctrl->out = out_target; //直接设置输出为目标输出
            ctrl->first_run = 0; //第一次运行标志置为0
        }
        else //如果不是第一次运行
        {
            float slew_limit = ctrl->cfg.slew_max * dt; //计算变化率限制值
            float delta = out_target - ctrl->out; //计算输出变化量
            if (delta > slew_limit) //如果输出变化量大于变化率限制值    
                delta = slew_limit; //将输出变化量限制为变化率限制值
            else if (delta < -slew_limit) //如果输出变化量小于负变化率限制值
                delta = -slew_limit; //将输出变化量限制为负变化率限制值
            ctrl->out += delta; //更新输出
        }
        if (ctrl->out > ctrl->cfg.out_max) //如果输出大于限幅值
            ctrl->out = ctrl->cfg.out_max; //将输出限制为限幅值
        else if (ctrl->out < -ctrl->cfg.out_max) //如果输出小于负限幅值
            ctrl->out = -ctrl->cfg.out_max; //将输出限制为负限幅值
        return ctrl->out; //返回当前输出
    }