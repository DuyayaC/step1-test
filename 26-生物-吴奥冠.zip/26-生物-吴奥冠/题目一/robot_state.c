#include "robot_state.h" //读取头文件
robot_state_t robot_state_step(robot_state_t cur, robot_event_t event)//函数
{
    switch (cur) //用switch分类讨论
    {
    case ROBOT_STATE_IDLE: //当前状态为空闲
        switch (event) //接受情况
        {
        case ROBOT_EVENT_START: //如果接受到启动事件
            return ROBOT_STATE_RUN; //启动
        case ROBOT_EVENT_FAULT: //如果接受到报故障事件
            return ROBOT_STATE_FAULT; //故障
        default:  //其他情况保持原状态
            return cur; //返回原本的值
        }
    case ROBOT_STATE_RUN: //当前状态为运行中
        switch (event) //接受情况
        {
        case ROBOT_EVENT_STOP: //如果接受到停止事件
            return ROBOT_STATE_IDLE; //返回空闲状态
        case ROBOT_EVENT_FAULT: //如果接受到报故障事件
            return ROBOT_STATE_FAULT; //故障
        default: //其他情况保持原状态
            return cur; //返回原本的值
        }
    case ROBOT_STATE_FAULT: //当前状态为故障
        switch (event)  //接受情况
        {
        case ROBOT_EVENT_CLEAR: //如果接受到清除故障事件
            return ROBOT_STATE_IDLE; //返回空闲状态
        default:  //其他情况保持原状态
            return cur; //返回原本的值
        }
    default: 
        return cur; // 未知状态，保持原状态
    }
}
